#!/bin/bash

# by locomootive
ping -c 1 www.google.com
rc=$?
if [[ $rc -ne 0 ]]; then
    nmcli device wifi connect UCLA_Guest
    curl -X POST -d "ok=Accept and Continue" -d "origurl=http%3a%2f%2fdetectportal%2efirefox%2ecom%2fcanonical%2ehtml" http://google.com/forms/guest_toued
    ./restart_cloudflared.sh
fi
