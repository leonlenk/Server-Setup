#!/bin/bash

systemctl restart cloudflared

